# basicFins
Каркас Spring Boot + Spring JPA + Spring Security + PostgeSQL + Thymeleaf

Отладка Security, сейчас закомментировал все
1. basicFins\src\main\java\com\sweetcard\basic -> config.zip, service.zip
2. basicFins\src\main\java\com\sweetcard\basic\dao\repository -> repository.zip
3. basicFins\src\main\java\com\sweetcard\basic\dao\entities -> entities.zip
4. Pom -> Закомментил seaurity