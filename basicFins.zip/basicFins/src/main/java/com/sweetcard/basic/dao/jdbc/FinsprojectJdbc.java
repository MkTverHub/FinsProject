package com.sweetcard.basic.dao.jdbc;

import com.sweetcard.basic.model.Financedataform;
import com.sweetcard.basic.model.Finsprojectform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by Admin on 09.03.2020.
 */
@Component
public class FinsprojectJdbc {
    private Logger logger = LoggerFactory.getLogger(FinancedataJdbc.class);
    @Autowired
    JdbcTemplate jdbcTemplate;
    //Создание записи
    public Integer NewFinsProject(Finsprojectform finsprojectform) {
        try{
            //Создание записи
            GeneratedKeyHolder holder = new GeneratedKeyHolder();
            jdbcTemplate.update(new PreparedStatementCreator() {
                @Override
                public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                    PreparedStatement statement = con.prepareStatement("INSERT INTO finsproject (name , description) VALUES (?,?) ", Statement.RETURN_GENERATED_KEYS);
                    statement.setString(1, finsprojectform.getFinsprojectname());
                    statement.setString(2, finsprojectform.getFinsprojectdescription());
                    return statement;
                }
            }, holder);

            String strProjectId = holder.getKeyList().get(0).get("id").toString();
            logger.info("FinsprojectJdbc.RecordOperation -> Project Id: " + strProjectId);
            return Integer.parseInt(strProjectId);

        }catch (Exception exp_sql){
            logger.info("FinsprojectJdbc.RecordOperation -> ERROR: " + exp_sql);
            return null;
        }
    }
}
