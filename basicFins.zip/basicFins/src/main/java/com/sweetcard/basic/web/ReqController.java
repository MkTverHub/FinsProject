package com.sweetcard.basic.web;

import com.sweetcard.basic.dao.entities.Requisits;
import com.sweetcard.basic.dao.repository.RequisitRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.sweetcard.basic.dao.entities.Response;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Admin on 15.02.2020.
 */
@Controller
@RequestMapping("/")
public class ReqController {
    private Logger logger = LoggerFactory.getLogger(ReqController.class);

    @Autowired
    RequisitRepository requisitRepository;
    /*
    @RequestMapping(value = "/Method_1", method = RequestMethod.POST)
    public String checkUser(@RequestParam(name = "ModelAttr_1", required = false, defaultValue = "весна ботинок") String name, Model model) {
        System.out.println("ReqController.Method_1 -> " + name);
        model.addAttribute("ModelAttr_1",name + "Attr_1_Value2");
        return "FinsPage_1";
    }*/

    @RequestMapping(value = "/Method_1", method = RequestMethod.GET)
    public @ResponseBody Response BtMethod1(@RequestParam String text) {
        System.out.println("ReqController.BtMethod1 -> " + text);
        Response result = new Response();
        if (text != null) {
            result.setText(text);
            result.setCount(text.length());
        }
        return result;
    }

    @RequestMapping(value = "/SetContrAgentRequisits", method = RequestMethod.GET)
    public @ResponseBody Response GetRequisitsList(@RequestParam String ContragentId) {
        System.out.println("ReqController.GetRequisitsList -> " + ContragentId);
        try{
            //Получить реквизиты контрагента
            List<Requisits> requisitsList = requisitRepository.GetAllByContragent(Integer.parseInt(ContragentId));

            String strHtmlRequisits = "";
            //Получения html контекста
            for(int i = 0; i < requisitsList.size(); i++){
                Requisits requisits = requisitsList.get(i);
                strHtmlRequisits = strHtmlRequisits +
                        "<option value=\""+requisits.id+"\">"+requisits.name+"</option>";
            }

            Response result = new Response();
            if (strHtmlRequisits != null) {
                result.setText(strHtmlRequisits);
                result.setCount(strHtmlRequisits.length());
            }
            return result;
        }catch (Exception ex_1){
            System.out.println("ReqController.GetRequisitsList -> Error: " + ex_1);
            Response result = new Response();
            result.setText("<option value=\"Error sql\">Error sql</option>");
            result.setCount(0);
            return result;
        }
    }
}
