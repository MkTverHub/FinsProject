package com.sweetcard.basic.web;

import com.sweetcard.basic.dao.entities.Contragent;
import com.sweetcard.basic.dao.entities.Financedata;
import com.sweetcard.basic.dao.entities.Finsproject;
import com.sweetcard.basic.dao.entities.Requisits;
import com.sweetcard.basic.dao.jdbc.ContragentJdbc;
import com.sweetcard.basic.dao.jdbc.FinsprojectJdbc;
import com.sweetcard.basic.dao.jdbc.RequisitJdbc;
import com.sweetcard.basic.dao.repository.ContragentRepository;
import com.sweetcard.basic.dao.repository.FinsprojectRepository;
import com.sweetcard.basic.dao.repository.RequisitRepository;
import com.sweetcard.basic.model.Cntragntreqform;
import com.sweetcard.basic.model.Contragentform;
import com.sweetcard.basic.model.Financedataform;
import com.sweetcard.basic.dao.jdbc.FinancedataJdbc;
import com.sweetcard.basic.dao.repository.FinancedataRepository;
import com.sweetcard.basic.model.Finsprojectform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

@Controller
public class WebController {
    private Logger logger = LoggerFactory.getLogger(WebController.class);
    //@Autowired
    //CustomerRepository customerRepository;
    @Autowired
    FinancedataRepository financedataRepository;
    @Autowired
    FinsprojectRepository finsprojectRepository;
    @Autowired
    ContragentRepository contragentRepository;
    @Autowired
    RequisitRepository requisitRepository;
    @Autowired
    FinancedataJdbc financedataJdbc;
    @Autowired
    FinsprojectJdbc finsprojectJdbc;
    @Autowired
    ContragentJdbc contragentJdbc;
    @Autowired
    RequisitJdbc requisitJdbc;

    //Общие переменные
    private String strActivProjectId = null;//Id текущего проекта
    private Integer intActivProjectId = null;//Id текущего проекта
    private String strActivContragentId = null;//Id текущего контрагента

    //Здесь вход на app
    @GetMapping({"/", "/index"})
    public String greeting(@RequestParam(name = "name", required = false, defaultValue = "весна ботинок") String name, Model model)
    {
        //Проект с max id
        strActivProjectId = finsprojectRepository.GetMaxId();
        logger.info("WebController.greeting -> ProjectId: " + strActivProjectId);
        intActivProjectId = Integer.parseInt(strActivProjectId);

        //Получить все записи financedata с группировкой по Id
        //List<Financedata> financedata = financedataRepository.findAllByOrderByIdAsc();

        List<Financedata> financedata = financedataRepository.GetAllByProj(intActivProjectId);//Получить все записи financedata по проекту
        List<Finsproject> finsproject = finsprojectRepository.findAllByOrderByIdAsc();//Получить все записи finsproject с группировкой по Id
        List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов


        model.addAttribute("financedata", financedata);//Дабавить модель запроса БД financedata
        model.addAttribute("finsproject", finsproject);//Дабавить модель запроса БД finsproject
        model.addAttribute("contragentlist", contragents);
        model.addAttribute("financedataform", new Financedataform());//Добавить модель form
        model.addAttribute("finsprojectform", new Finsprojectform());//Добавить модель form
        return "FinsPage_2";
    }

    //Метод кнопки "Сохранить" финс формы
    @RequestMapping(value = "/UpdateFinseRecord", method = RequestMethod.POST)
    public String checkUser(@ModelAttribute Financedataform financedataform, Model model) {
        //Апдейт записи
        financedataJdbc.setActivProjectId(intActivProjectId);
        financedataJdbc.RecordOperation(financedataform);

        //Получить все записи financedata по проекту
        List<Financedata> financedata = financedataRepository.GetAllByProj(intActivProjectId);
        List<Finsproject> finsproject = finsprojectRepository.findAllByOrderByIdAsc();
        List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов

        model.addAttribute("contragentlist", contragents);
        model.addAttribute("financedata", financedata);//Дабавить модель запроса БД
        model.addAttribute("finsproject", finsproject);//Дабавить модель запроса БД finsproject
        model.addAttribute("financedataform",financedataform);//Добавить модель form
        model.addAttribute("finsprojectform", new Finsprojectform());//Добавить модель form
        return "FinsPage_2";
    }

    @RequestMapping(value = "/NewFinsProj", method = RequestMethod.POST)
    public String newFinsProject(@ModelAttribute Finsprojectform finsprojectform, Model model){
        finsprojectJdbc.NewFinsProject(finsprojectform);

        logger.info("WebController.newFinsProject: " + finsprojectform.getFinsprojectname());
        List<Financedata> financedata = financedataRepository.findAllByOrderByIdAsc();
        List<Finsproject> finsproject = finsprojectRepository.findAllByOrderByIdAsc();
        List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов

        model.addAttribute("contragentlist", contragents);
        model.addAttribute("financedata", financedata);//Дабавить модель запроса БД financedata
        model.addAttribute("finsproject", finsproject);//Дабавить модель запроса БД finsproject
        model.addAttribute("financedataform", new Financedataform());//Добавить модель form
        model.addAttribute("finsprojectform", new Finsprojectform());//Добавить модель form

        return "FinsPage_2";
    }

    @RequestMapping(value = "/SetFinsProj", method = RequestMethod.POST)
    public String setFinsProject(@ModelAttribute Finsprojectform finsprojectform, Model model){

        logger.info("WebController.SetFinsProj: " + finsprojectform.getFinsprojectid());
        intActivProjectId = Integer.parseInt(finsprojectform.getFinsprojectid());
        financedataJdbc.setActivProjectId(intActivProjectId);

        //Получить все записи financedata по проекту
        List<Financedata> financedata = financedataRepository.GetAllByProj(intActivProjectId);
        List<Finsproject> finsproject = finsprojectRepository.findAllByOrderByIdAsc();
        List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов

        model.addAttribute("contragentlist", contragents);
        model.addAttribute("financedata", financedata);//Дабавить модель запроса БД financedata
        model.addAttribute("finsproject", finsproject);//Дабавить модель запроса БД finsproject
        model.addAttribute("financedataform", new Financedataform());//Добавить модель form
        model.addAttribute("finsprojectform", new Finsprojectform());//Добавить модель form

        return "FinsPage_2";
    }

    @RequestMapping(value = "/Projects", method = RequestMethod.POST)
    public String GoToProjects(Model model){
        logger.info("WebController.GoToProjects -> ");

        //Получить все записи finsproject с группировкой по Id
        List<Finsproject> finsproject = finsprojectRepository.GetAllClc();
        model.addAttribute("finsproject", finsproject);//Дабавить модель запроса БД finsproject
        model.addAttribute("finsprojectform", new Finsprojectform());//Добавить модель form
        return "Fins_Projects";
    }

    @RequestMapping(value = "/NewFinsProj2", method = RequestMethod.POST)
    public String NewFinsProject2(@ModelAttribute Finsprojectform finsprojectform, Model model){
        logger.info("WebController.NewFinsProject2 -> ");
        finsprojectJdbc.NewFinsProject(finsprojectform);
        //Получить все записи finsproject с группировкой по Id
        List<Finsproject> finsproject = finsprojectRepository.GetAllClc();
        model.addAttribute("finsproject", finsproject);//Дабавить модель запроса БД finsproject
        model.addAttribute("finsprojectform", new Finsprojectform());//Добавить модель form
        return "Fins_Projects";
    }

    //Переход на страницу контрагентов
    @RequestMapping(value = "/Contragents", method = RequestMethod.POST)
    public String GoToContragents(Model model){
        try{
            logger.info("WebController.GoToContragents -> ");

            strActivContragentId = contragentRepository.GetMaxId().toString();//Установка активного контрагента
            List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов
            List<Requisits> requisits = requisitRepository.GetAllByContragent(Integer.parseInt(strActivContragentId));//Получить реквизиты контрагента

            model.addAttribute("contragentform", new Contragentform());//Контрагент
            model.addAttribute("requisitform", new Cntragntreqform());//Реквизит
            model.addAttribute("contragentlist", contragents);
            model.addAttribute("requisitslist", requisits);
            return "Fins_Contragents";
        }catch (Exception req_ex1){
            logger.info("WebController.GoToContragents -> ERROR: " + req_ex1);
            return "error";
        }
    }

    //Выбор контрагента из списка контрагентов
    @RequestMapping(value = "/SelectContragent", method = RequestMethod.POST)
    public String SelectContragent(@ModelAttribute Contragentform contragentform, Model model){
        try {
            logger.info("WebController.SelectContragent -> ");
            //ВНИМАНИ: contragentform это контекст СКРЫТОЙ формы выделения контрагента
            contragentform.setContragentaction("update");
            strActivContragentId = contragentform.getContragentid();
            Integer IntActivContragent = Integer.parseInt(strActivContragentId);

            List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов
            List<Requisits> requisits = requisitRepository.GetAllByContragent(IntActivContragent);//Получить реквизиты активного контрагента

            model.addAttribute("contragentform", contragentform);//Контрагент
            model.addAttribute("requisitform", new Cntragntreqform());//Реквизит
            model.addAttribute("contragentlist", contragents);
            model.addAttribute("requisitslist", requisits);

            return "Fins_Contragents";
        }catch (Exception req_ex){
            logger.info("WebController.SelectContragent -> ERROR: " + req_ex);
            return "error";
        }
    }

    //Событие БД контрагента
    @RequestMapping(value = "/Contragentaction", method = RequestMethod.POST)
    public String Contragentaction(@ModelAttribute Contragentform contragentform, Model model){
        try {
            logger.info("WebController.Contragentaction -> ");

            contragentJdbc.Contragentaction(contragentform);//Отработка события БД

            strActivContragentId = contragentRepository.GetMaxId().toString();//Установка активного контрагента

            List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов
            List<Requisits> requisits = requisitRepository.GetAllByContragent(Integer.parseInt(strActivContragentId));//Получить реквизиты активного контрагента

            model.addAttribute("contragentform", new Contragentform());//Контрагент
            model.addAttribute("requisitform", new Cntragntreqform());//Реквизит
            model.addAttribute("contragentlist", contragents);
            model.addAttribute("requisitslist", requisits);
            return "Fins_Contragents";
        }catch (Exception req_ex5){
            logger.info("WebController.Contragentaction -> ERROR: " + req_ex5);
            return "error";
        }
    }

    //Событие БД реквизита
    @RequestMapping(value = "/Requisitaction", method = RequestMethod.POST)
    public String Requisitaction(@ModelAttribute Cntragntreqform cntragntreqform, Model model){
        try {
            logger.info("WebController.Requisitaction -> ");

            requisitJdbc.SetContragentId(strActivContragentId);
            requisitJdbc.Requisitaction(cntragntreqform);

            List<Contragent> contragents = contragentRepository.findAllByOrderByIdAsc();//Получить всех контрагентов
            List<Requisits> requisits = requisitRepository.GetAllByContragent(Integer.parseInt(strActivContragentId));//Получить реквизиты активного контрагента

            model.addAttribute("contragentform", new Contragentform());//Контрагент
            model.addAttribute("requisitform", new Cntragntreqform());//Реквизит
            model.addAttribute("contragentlist", contragents);
            model.addAttribute("requisitslist", requisits);
            return "Fins_Contragents";
        }catch (Exception req_ex3){
            logger.info("WebController.Requisitaction -> ERROR: " + req_ex3);
            return "error";
        }
    }

    @RequestMapping(value = "/Reports", method = RequestMethod.POST)
    public String GoToReports(Model model){
        return "Fins_Reports";
    }

}
