package com.sweetcard.basic.dao.entities;

import lombok.Data;

import javax.persistence.*;

/**
 * Created by Admin on 07.03.2020.
 */
@Data
@Entity
public class Finsproject {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    @Column(name = "name")
    private String name;
    @Column(name = "description")
    private String description;
    //@Column(name = "clc_1")//Пример калькулируемого поля
   // private String clc_1;

}
