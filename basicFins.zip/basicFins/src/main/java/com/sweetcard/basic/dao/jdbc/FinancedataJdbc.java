package com.sweetcard.basic.dao.jdbc;

import com.sweetcard.basic.model.Financedataform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

/**
 * Created by Admin on 21.02.2020.
 */
@Component
public class FinancedataJdbc {
    private Logger logger = LoggerFactory.getLogger(FinancedataJdbc.class);
    private Integer intActivProjectId = null;//Id текущего проекта
    @Autowired
    JdbcTemplate jdbcTemplate;

    //Апдейт записи
    public void RecordOperation(Financedataform finsform)
    {
        try {
            String strEditType = finsform.getFinsedittype();
            logger.info("FinancedataJdbc.RecordOperation: strEditType = " + strEditType);
            String strRecordId = finsform.getFinsrecordid();
            logger.info("FinancedataJdbc.RecordOperation: strRecordId = " + strRecordId);
            String strFinsOperType = finsform.getFinsOperType();
            logger.info("FinancedataJdbc.RecordOperation: strFinsOperType = " + strFinsOperType);
            String strAmount = finsform.getFinsamount();
            logger.info("FinancedataJdbc.RecordOperation: strAmount = " + strAmount);
            String strPaymentAccIn = finsform.getPaymentAccIn();
            logger.info("FinancedataJdbc.RecordOperation: strPaymentAccIn = " + strPaymentAccIn);
            String strPaymentAccOut = finsform.getPaymentAccOut();
            logger.info("FinancedataJdbc.RecordOperation: strPaymentAccOut = " + strPaymentAccOut);
            String strFinsArticle = finsform.getFinsArticle();
            logger.info("FinancedataJdbc.RecordOperation: strFinsArticle = " + strFinsArticle);
            //String strProjectId = finsform.getProjectId();
            String strProjectId = intActivProjectId.toString();
            logger.info("FinancedataJdbc.RecordOperation: strProjectId = " + strProjectId);
            String strDetail = finsform.getFinsdetail();
            logger.info("FinancedataJdbc.RecordOperation: strDetail = " + strDetail);
            String strContrAgent = finsform.getFinscontragent();
            logger.info("FinancedataJdbc.RecordOperation: strContrAgent = " + strContrAgent);
            String strRequisites = finsform.getRequisites();
            logger.info("FinancedataJdbc.RecordOperation: strRequisites = " + strRequisites);

            Integer intRecordId = null;
            Integer intEditType = null;
            Integer intAmount = null;
            Integer intFinsOperType = null;
            if(strEditType != null && 0 != strEditType.compareTo("")){
                intEditType = Integer.parseInt(strEditType);
            }
            if(strRecordId != null && 0 != strRecordId.compareTo("")){
                intRecordId = Integer.parseInt(strRecordId);
            }
            if(strAmount != null && 0 != strAmount.compareTo("")){
                intAmount = Integer.parseInt(strAmount);
            }
            if(strFinsOperType != null && 0 != strFinsOperType.compareTo("")){
                intFinsOperType = Integer.parseInt(strFinsOperType);
            }
            /*
            if(strProjectId != null && 0 != strProjectId.compareTo("")){
                intProjectId = Integer.parseInt(strProjectId);
            }
            */

            //Обновление записи
            if (intEditType == 1) {
                logger.info("FinancedataJdbc.RecordOperation (1 Update): ");
                jdbcTemplate.update("update financedata set oper_date = now()::timestamp, fins_oper_type = ?, amount = ?, pay_acc_in = ? , pay_acc_out = ? , fins_article = ?, project_id = ?, detail = ?,  finscontragent = ?, requisites = ? where id = ?",intFinsOperType ,intAmount, strPaymentAccIn, strPaymentAccOut, strFinsArticle, intActivProjectId, strDetail, strContrAgent, strRequisites, intRecordId);
            }

            //Создание записи
            if (intEditType == 2) {
                logger.info("FinancedataJdbc.RecordOperation (2 Insert): ");
                jdbcTemplate.update("insert into financedata (oper_date, fins_oper_type, amount, pay_acc_in, pay_acc_out, fins_article, project_id, detail, finscontragent, requisites) values (now()::timestamp, ?, ?, ?, ?, ?, ?, ?, ?, ?)", intFinsOperType ,intAmount, strPaymentAccIn, strPaymentAccOut, strFinsArticle, intActivProjectId, strDetail, strContrAgent, strRequisites);
                finsform.ClearFields();
            }

            //Удаление записи
            if (intEditType == 3) {
                jdbcTemplate.update("delete from financedata where id = ? and project_id = ?", intRecordId, intActivProjectId);
                finsform.ClearFields();
            }

        }catch (Exception ex){
            logger.info("FinancedataJdbc.RecordOperation ERROR: " + ex);
        }
    }

    //-----------------------------SETTERS------------------------------
    public void setActivProjectId(Integer ProjectId){
        intActivProjectId = ProjectId;
    }

}
