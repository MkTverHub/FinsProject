package com.sweetcard.basic.dao.entities;

/**
 * Created by Admin on 19.02.2020.
 */
public class Response {
    private int count;
    private String text;

    public int getCount() {
        return count;
    }
    public void setCount(int count) {
        this.count = count;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
}
