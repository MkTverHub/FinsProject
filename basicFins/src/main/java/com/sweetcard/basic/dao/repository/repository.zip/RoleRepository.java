package com.sweetcard.basic.dao.repository;



import com.sweetcard.basic.dao.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
